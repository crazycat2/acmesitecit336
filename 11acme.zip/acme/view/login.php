<!DOCTYPE html>
<html>
<head>
<title>index</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="../css/acme.css">
</head>

<body>
<header>
<img src="images/site/logo.gif">
</header>
<nav>
<?php include 'nav.php' ?> 
</nav>  
    
<main>
<h1>Login Page</h1>
</main>
<main2>
<?php
if (isset($message)) {
 echo $message;
}
?>
    <form action="/acme/accounts/index.php" method="POST">
    <fieldset>

        Email Address:<br>
        <input type="email" name="email" required placeholder="Enter a valid email address"><br>
<label for="password">Password:</label>
<!--<span>Passwords must be at least 8 characters and contain at least 1 number, 1 capital letter and 1 special character</span>-->
User password:<br>
<input type="password" name="password" id="password" required >
 <!--pattern="(?=^.{8,}$)(?=.*\d)(?=.*\W+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$"-->       
      
        <input type="submit" value="login">
        <input type="hidden" name="action" value="Login">
    </fieldset>
</form>  
<a href="/acme/accounts/index.php?action=reg">Not a member? Register Here!</a>
</main2>

<footer>
&copy Acme All rights reserved. All images are under fair use | Last Updated: 4/28/17
</footer>
</body>

</html>