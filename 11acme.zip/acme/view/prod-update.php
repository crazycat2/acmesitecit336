<?php
/* @var $clientLevel type */
if (!($_SESSION['clientData']['clientLevel'] > 1)) {
header ('Location ../view/registration.php');
exit;}
?>
<?php
// Build the categories option list
$catList = '<select name="catType" id="catType">';
$catList .= "<option>Choose a Category</option>";
foreach ($categories as $category) {
 $catList .= "<option value='$category[categoryId]'";
  if(isset($catType)){
   if($category['categoryId'] === $catType){
   $catList .= ' selected ';
  }
 } elseif(isset($prodInfo['categoryId'])){
  if($category['categoryId'] === $prodInfo['categoryId']){
   $catList .= ' selected ';
  }
}
$catList .= ">$category[categoryName]</option>";
}
$catList .= '</select>';
?>
<!DOCTYPE html>
<html>
<head>
<title>index
<?php if(isset($prodInfo['invName'])){ echo "Modify $prodInfo[invName] ";} elseif(isset($prodName)) { echo $prodName; }?> | Acme, Inc
</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="../css/acme.css">
</head>

<body>
<header>
<img src="images/site/logo.gif">
</header>
<nav>
<?php include 'nav.php' ?> 
</nav>  
    
<main>
<h1><?php if(isset($prodInfo['invName'])){ echo "Modify $prodInfo[invName] ";} elseif(isset($prodName)) { echo $prodName; }?></h1>
<h1>add products</h1>
</main>
<main2>
    
    
  
<?php
if (isset($message)) {
 echo $message;
}
?>
<form method="post" action="/acme/products/index.php">

<form method="post" action="/acme/products/index.php"><?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <fieldset>
        product name<br>
        <input type="text" name="invName"><br>
         description<br>
        <input type="text" name="invDescription"><br>
         image<br>
        <input type="text" name="invImage"><br>
         thumbnail<br>
        <input type="text" name="invThumbnail"><br>
         price<br>
        <input type="number" name="invPrice"><br>
         stock<br>
        <input type="number" name="invStock"><br>
         size<br>
        <input type="number" name="invSize"><br>
         weight<br>
        <input type="number" name="invWeight"><br>
         location<br>
        <input type="text" name="invLocation"><br>
        vendor<br>
        <input type="text" name="invVendor"><br>
        category <br>
        <?php
         echo $catList;
        ?>
         
        style<br>
        <input type="text" name="invStyle"><br>
        <input type="submit" value="update">
        <input type="hidden" name="action" value="updateProd">
        <input type="hidden" name="prodId" value="<?php if(isset($prodInfo['invId'])){ echo $prodInfo['invId'];} elseif(isset($prodId)){ echo $prodId; } ?>">
    </fieldset>
</form>  
    
</main2>

<footer>
&copy Acme All rights reserved. All images are under fair use | Last Updated: 4/28/17
</footer>
</body>

</html>