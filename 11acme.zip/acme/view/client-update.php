<?php
if (
$loggedin = false){
header ('Location ../view/registration.php');
exit;
}
;?>


<!DOCTYPE html>
<html>
<head>
<title>index
<?php if(isset($clientData['clientId'])){ echo "Modify $clientData[clientId] ";} elseif(isset($clientFirstname)) { echo $clientFirstname; }?> | Acme, Inc
</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="../css/acme.css">
</head>

<body>
<header>
<img src="images/site/logo.gif" alt="logo">
</header>
<nav>
<?php include 'nav.php' ?>
</nav>  
    
<main>  
<h1>Update Account</h1><?php if(isset($clientData['clientId'])){ echo $clientData['clientId'];} elseif(isset($clientFirstname)){ echo $clientFirstname; } ?>
</main>
<main2>
<?php
if (isset($message)) {
 echo $message;
}
?>
<form method="post" action="/acme/accounts/index.php">
<fieldset>
  First name:<br>
  <input type="text" name="clientFirstname" value="<?php if(isset($clientFirstname)){echo $clientFirstname;}else {echo $_SESSION['clientData']['clientFirstname'];
      
  }
  ?>"><br>
  Last name:<br>
  <input type="text" name="clientLastname" value="<?php if(isset($clientLastname)){echo $clientLastname;}else {echo $_SESSION['clientData']['clientLastname']; }
  ?>">
  email:<br>
  <input type="text" name="clientEmail" value="<?php if(isset($clientEmail)){echo $clientEmail;}else {echo $_SESSION['clientData']['clientEmail']; }
  ?>">
  <input type="submit" value="update account info">
  <input type="hidden" name="action" value="updateClient">
  <input type="hidden" name="clientId" value="<?php echo $_SESSION['clientData']['clientId'] ?>">
</fieldset>
</form>
    
    <form method="post" action="/acme/accounts/index.php">
        <fieldset>
                password:<br>
                <input type="password" name="clientPassword">
                <input type="submit" value="updatePassword">
                <input type="hidden" name="action" value="updatePassword">
                <input type="hidden" name="clientId" value="<?php if(isset($clientId['clientId'])){ echo $clientId['clientId'];} elseif(isset($clientId)){ echo $clientId; } ?>">
        </fieldset>
    </form>
</main2>

<footer>
&copy; Acme All rights reserved. All images are under fair use | Last Updated: 4/28/17
</footer>
</body>

</html>