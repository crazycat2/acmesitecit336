<!DOCTYPE html>
<html>
<head>
<title>index</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="../css/acme.css">
</head>

<body>
<header>
<img src="images/site/logo.gif">
</header>
<nav>
<?php include 'nav.php' ?> 
</nav>  
    
<main>
<h1>Registration Page</h1>
</main>
<main2>
    
    
 <?php
// define variables and set to empty values
$fnameErr = $lnameErr = $emailErr = $pswErr = $genderErr = $websiteErr = "";
$fname = $lname = $email = $psw = $gender = $comment = $website = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["fname"])) {
    $fnameErr = "first name is required";
  } else {
    $fname = test_input($_POST["fname"]);
  }
  
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["lname"])) {
    $lnameErr = "last name is required";
  } else {
    $lname = test_input($_POST["lname"]);
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
  }
    
  if (empty($_POST["psw"])) {
    $pswErr = "password is required";
  } else {
    $psw = test_input($_POST["psw"]);
  }

  if (empty($_POST["comment"])) {
    $comment = "";
  } else {
    $comment = test_input($_POST["comment"]);
  }

  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }
}
}
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>   

    
<?php
if (isset($message)) {
 echo $message;
}
?>
<form method="post" action="/acme/accounts/index.php">
       
<form method="post" action="/acme/accounts/index.php"><?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <fielset>
        First Name:<br>
        <input type="text" name="fname"><br><?php if(isset($firstname)){echo "value='$firstname'";} ?>
        <span class="error">* <?php echo $fnameErr;?></span>
        Last Name:<br>
        <input type="text" name="lname"><br>
        <span class="error">* <?php echo $lnameErr;?></span>
        Email Address:<br>
        <input type="text" name="email"><br>
        <span class="error">* <?php echo $emailErr;?></span>
        User password:<br>
        <input type="password" name="psw">
        <span class="error">* <?php echo $pswErr;?></span>
        <br><input type="submit" name="submit" value="Submit">
        <!-- Add the action name - value pair -->
        <input type="hidden" name="action" value="register">
    </fielset>
</form>  
    <a href="/acme/accounts/index.php?action=login">Login Here</a>
</main2>

<footer>
&copy Acme All rights reserved. All images are under fair use | Last Updated: 4/28/17
</footer>
</body>

</html>