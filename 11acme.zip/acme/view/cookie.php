<?php 
    if(isset($_SESSION['clientData'])){
     $firstname = $_SESSION['clientData']['clientFirstname'];
     echo "<a href='/acme/accounts/index.php?action=admin'><span>Welcome $firstname</span></a>";
    }
    if(isset($_SESSION['loggedin'])){
        echo '<a href="/acme/accounts/index.php?action=Logout" id="my_account"><img src="/acme/images/site/account.gif" alt="My Account thumnbnail" width="30"><span>Logout</span></a></div>';
    }
    else {
        echo '<a href="/acme/accounts/index.php?action=login" id="my_account"><img src="/acme/images/site/account.gif" alt="My Account thumnbnail" width="30"><span>My Account</span></a></div>';
    }
    ?>
