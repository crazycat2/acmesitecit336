

   <figure>
    <img src="/acme/images/products/anvil.png" alt="cactus" >
    <figcaption class="text-overlay">Anvil</figcaption>
    </figure>
    
    <figure>
    <img src="images/products/anvil.png alt="cactus">
    <figcaption class="text-overlay">Anvil</figcaption>
    </figure>


.text-overlay {
    postion:relative;
    bottom: 8em;
    left:10em;
}