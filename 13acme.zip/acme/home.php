<!DOCTYPE html>
<html>
<head>
<title>index</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="css/acme.css">
</head>

<body>
<header>
<img src="images/site/logo.gif" alt="logo">
</header>
<nav>
<?php echo $navList; ?>
<?php include '../acme/view/cookie.php' ?>
</nav>  
    
<main>
<img src="images/site/rocketfeature.jpg" alt="rocket">
<div class="topright"><h1>Welcome to Acme!</h1>
Acme Rocket<img src="images/site/iwantit.gif" alt="iwant"></div>

</main>
<main2>
<?php include '../acme/view/main2.php' ?> 
</main2>
<div id="folder">
<img src="images/site/account.gif" alt="account-folder">
<?php if(isset($cookieFirstname)){
  echo "<span>Welcome $cookieFirstname</span>";
} ?>
<a href="/acme/accounts/index.php?action=login" alt="redirect-php">accounts</a>
</div>
<footer>
&copy; Acme All rights reserved. All images are under fair use | Last Updated: 7/12/17
</footer>
</body>

</html>
