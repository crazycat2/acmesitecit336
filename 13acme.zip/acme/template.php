<!DOCTYPE html>
<html>
<head>
<title>index</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="../css/acme.css">
</head>

<body>
<header>
<img src="images/site/logo.gif" alt="logo">
</header>
<nav>
<?php include 'nav.php' ?> 
<?php 
    if(isset($cookieFirstname)){
     echo "<span>Welcome $cookieFirstname</span>";
    }
    if(isset($_SESSION['loggedin'])){
        echo '<a href="/acme/accounts/index.php?action=Logout" id="my_account"><img src="/acme/images/site/account.gif" alt="My Account thumnbnail" width="30"><span>Logout</span></a></div>';
    }
    else {
        echo '<a href="/acme/accounts/index.php?action=login" id="my_account"><img src="/acme/images/site/account.gif" alt="My Account thumnbnail" width="30"><span>My Account</span></a></div>';
    }
    ?>

</nav>  
    
<main>
<h1>Content Title Here</h1>
</main>
<main2>
</main2>

<footer>
&copy; Acme All rights reserved. All images are under fair use | Last Updated: 6/27/17
</footer>
</body>
</html>
