<?php
if (isset($_SESSION['message'])) {
 $message = $_SESSION['message'];
}?>
<!DOCTYPE html>
<html>
<head>
<title>review management</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="../css/acme.css">
</head>

<body>
<header>
<img src="images/site/logo.gif" alt="logo">
</header>
<nav>
<?php include 'nav.php' ?> 
<?php include 'cookie.php'?>
</nav>  
    
<main>
<h1>Delete Reviews</h1>
</main>
<main2>

<?php
if (isset($message)) {
echo $message;
}
?>


        review <br>
        <?php if(isset($revInfo['revId'])) {echo "value='$revInfo[revId]'"; }?>><br>
         description<br>
        <?php if(isset($revInfo['reviewText'])) {echo $revInfo['reviewText']; } ?><br>

        <?php
         echo $revList;
        ?>
        <form method="post" action="/acme/reviews/index.php">
        <input type="submit" value="delete">
        <input type="hidden" name="action" value="deletereview">
        <input type="hidden" name="revId" value="<?php if(isset($revInfo['InvId'])){ echo $revInfo['InvId'];} elseif(isset($revId)){ echo $revId; } ?>">
        </form>

<footer>
&copy; Acme All rights reserved. All images are under fair use | Last Updated: 4/28/17
</footer>
</body>
</html>
<?php unset($_SESSION['message']); ?>