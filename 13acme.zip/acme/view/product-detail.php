<!DOCTYPE html>
<html>
<head>
<title><?php echo $type; ?> Product Detail</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="../css/acme.css">
</head>

<body>
<header>
<img src="images/site/logo.gif" alt="logo">
</header>
<nav>
<?php include 'nav.php' ?> 
<?php include 'cookie.php' ?>
</nav>  
    
<main>
<?php if(isset($message)){ echo $message; } ?>
<?php if(isset($productdetail)){ echo $productdetail; } ?>
</main>
<main2><?php if(isset($productThumbnail)){ echo $productThumbnail; } ?></main2>

    <?php if($_SESSION['loggedin'] == TRUE):?>
<form action="/acme/reviews/" method="post" enctype="multipart/form-data">
<textarea rows="10" cols="30" name="reviewText">
The cat was playing in the garden.
</textarea><br>
 <input type="submit" class="regbtn" value="Submit Review">
 <input type="hidden" name="action" value="upload">    
 <input type="hidden" name="InvId" value="<?php echo $des['invId'];?>">    
 <input type="hidden" name="clientId" value="<?php echo $_SESSION['clientData']['clientId'];?>">    
 </form>
<?php endif;?>
<?php if (isset($productReviews)){ echo $productReviews;} ?>
</body>
<footer>
&copy; Acme All rights reserved. All images are under fair use | Last Updated: 4/28/17
</footer>
</html>