<!DOCTYPE html>
<html>
<head>
<title><?php echo $type; ?> Products</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="../css/acme.css">
</head>

<body>
<header>
<img src="images/site/logo.gif" alt="logo">
</header>
<nav>
<?php include 'nav.php' ?> 
</nav>  
    
<main>
<h1><?php echo $type; ?> Products</h1>
</main>
<?php if(isset($message)){ echo $message; } ?>
<?php if(isset($prodDisplay)){ echo $prodDisplay; } ?>


<footer>
&copy; Acme All rights reserved. All images are under fair use | Last Updated: 4/28/17
</footer>
</body>
</html>


