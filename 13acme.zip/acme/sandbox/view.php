<html>
    <head>
    <title></title>
    </head>
    <body>   
        <?php
        echo $value;
        
        ?>
    </body>
     
</html>