<?php

/*
  products controlller
 */
// Create or access a Session
session_start();

// Get the database connection file
require_once '../library/connections.php';
// Get the acme model for use as needed
require_once '../model/acme-model.php';
// Get the acme model for use as needed
require_once '../model/uploads-model.php';
// Get the accounts model
require_once '../model/accounts-model.php';
require_once '../model/products-model.php';
require_once '../model/reviews-model.php';
require_once '../library/functions.php';

if(isset($_COOKIE['firstname'])){
  $cookieFirstname = filter_input(INPUT_COOKIE, 'firstname', FILTER_SANITIZE_STRING);
}

// Get the array of categories
$categories = getCategories();

// Build a navigation bar using the $categories array
$navList = '<ul>';
$navList .= "<li><a href='/acme/index.php' title='View the Acme home page'>Home</a></li>";
foreach ($categories as $category) {
    $navList .= "<li><a href='/acme/index.php?action=$category[categoryName]' title='View our $category[categoryName] product line'>$category[categoryName]</a></li>";
}
$navList .= '</ul>';

$catList = '<Select name="category">';

foreach ($categories as $category) {
    $catList .= '<option value = "'.$category['categoryId'].'">'.$category['categoryName'].'</option>';
}
$catList .= '</select>';

if (isset($_POST['action'])){
 $action = filter_input(INPUT_POST, 'action');   
} else if (isset($_GET['action'])){
   $action = filter_input(INPUT_GET, 'action'); 
} else {
     $action = "showproducts";
}


switch ($action) {
    case 'showproducts':
$products = getProductBasics();
 if(count($products) > 0){
  $prodList = '<table>';
  $prodList .= '<thead>';
  $prodList .= '<tr><th>Product Name</th><td>&nbsp;</td><td>&nbsp;</td></tr>';
  $prodList .= '</thead>';
  $prodList .= '<tbody>';
  foreach ($products as $product) {
   $prodList .= "<tr><td>$product[invName]</td>";
   $prodList .= "<td><a href='/acme/products?action=mod&id=$product[invId]' title='Click to modify'>Modify</a></td>";
   $prodList .= "<td><a href='/acme/products?action=del&id=$product[invId]' title='Click to delete'>Delete</a></td></tr>";
  }
   $prodList .= '</tbody></table>';
  } else {
   $message = '<p class="notify">Sorry, no products were returned.</p>';
}
 include '../view/project-management.php';
break;

   
        include '../view/project-management.php';
        break;
    case "addproducts":
        include '../view/add-product.php';
        break;
    case "addcategory":
        $categoryName= filter_input(INPUT_POST, 'categoryName');
        // Check for missing data
        if (empty($categoryName)) {
            $message = '<p>Please provide information for all empty form fields.</p>';
            include '../view/add-category.php';
            exit;
        }
        $result = addcategories($categoryName);

        if ($result == 1){
            header("Location:http://localhost/acme/products/");
        } else {
            $message = "sorry error";
            include "../acme/view/add-category.php";
        }
        break;
    case "addnewproduct":

$productName= filter_input(INPUT_POST, 'invName', FILTER_SANITIZE_STRING);
$invDescription= filter_input(INPUT_POST, 'invDescription', FILTER_SANITIZE_STRING);
$invImage= filter_input(INPUT_POST, 'invImage', FILTER_SANITIZE_URL);
$invThumbnail= filter_input(INPUT_POST, 'invThumbnail', FILTER_SANITIZE_URL);
$invPrice= filter_input(INPUT_POST, 'invPrice', FILTER_SANITIZE_NUMBER_FLOAT);
$invStock= filter_input(INPUT_POST, 'invStock', FILTER_SANITIZE_NUMBER_INT);
$invSize= filter_input(INPUT_POST, 'invSize', FILTER_SANITIZE_NUMBER_INT);
$invWeight= filter_input(INPUT_POST, 'invWeight', FILTER_SANITIZE_NUMBER_INT);
$invLocation= filter_input(INPUT_POST, 'invLocation', FILTER_SANITIZE_STRING);
$invVendor= filter_input(INPUT_POST, 'invVendor', FILTER_SANITIZE_STRING);
$invStyle= filter_input(INPUT_POST, 'invStyle', FILTER_SANITIZE_STRING);
$category= filter_input(INPUT_POST, 'catType', FILTER_SANITIZE_STRING);



        // Check for missing data
        if (empty($productName)|| empty($invDescription)|| empty($invImage)|| empty($invThumbnail)|| empty($invPrice)|| empty($invStock)|| empty($invStock)|| empty($invSize)|| empty($invWeight)|| empty($invLocation)|| empty($invVendor)|| empty($invStyle) || empty($category)) {
            $message = '<p>Please provide information for all empty form fields.</p>';
            include '../view/add-product.php';
            exit;
        }
        // Send the data to the model
        
        $result = addproducts($productName, $invDescription ,$invImage,$invThumbnail, $invPrice, $invStock,$invSize, $invWeight, $invLocation,$invVendor,$invStyle,$category);
// Check and report the result
        if ($result === 1) {
            $message = "<p>Thanks for registering $productName";
            include '../view/project-management.php';
        } else {
            $message = "<p>fail. Please try again.</p>";
             include '../view/add-product.php';
        }
        break;
    default:
    include '../view/project-management.php';
    break;
    
 case 'mod':
 $prodId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
 $prodInfo = getProductInfo($prodId);
 if(count($prodInfo)<1){
  $message = 'Sorry, no product information could be found.';
 }
 include '../view/prod-update.php';
 exit;
break;

case 'updateProd':
$productName= filter_input(INPUT_POST, 'invName', FILTER_SANITIZE_STRING);
$invDescription= filter_input(INPUT_POST, 'invDescription', FILTER_SANITIZE_STRING);
$invImage= filter_input(INPUT_POST, 'invImage', FILTER_SANITIZE_URL);
$invThumbnail= filter_input(INPUT_POST, 'invThumbnail', FILTER_SANITIZE_URL);
$invPrice= filter_input(INPUT_POST, 'invPrice', FILTER_SANITIZE_NUMBER_FLOAT);
$invStock= filter_input(INPUT_POST, 'invStock', FILTER_SANITIZE_NUMBER_INT);
$invSize= filter_input(INPUT_POST, 'invSize', FILTER_SANITIZE_NUMBER_INT);
$invWeight= filter_input(INPUT_POST, 'invWeight', FILTER_SANITIZE_NUMBER_INT);
$invLocation= filter_input(INPUT_POST, 'invLocation', FILTER_SANITIZE_STRING);
$invVendor= filter_input(INPUT_POST, 'invVendor', FILTER_SANITIZE_STRING);
$invStyle= filter_input(INPUT_POST, 'invStyle', FILTER_SANITIZE_STRING);
$category= filter_input(INPUT_POST, 'catType', FILTER_SANITIZE_STRING);
$prodId = filter_input(INPUT_POST, 'prodId', FILTER_SANITIZE_NUMBER_INT);

 if (empty($productName)|| empty($invDescription)|| empty($invImage)|| empty($invThumbnail)|| empty($invPrice)|| empty($invStock)|| empty($invStock)|| empty($invSize)|| empty($invWeight)|| empty($invLocation)|| empty($invVendor)|| empty($invStyle) || empty($category) || empty($prodId)) {
  $message = '<p>Please complete all information for the new item! Double check the category of the item.</p>';
 include '../view/prod-update.php';
 exit;
}
$updateResult = updateProduct($productName, $invDescription ,$invImage,$invThumbnail, $invPrice, $invStock,$invSize, $invWeight, $invLocation,$invVendor,$invStyle,$category, $prodId);
 if ($updateResult) {
  $message = "<p class='notice'>Congratulations, $productName was successfully updated.</p>";
  $_SESSION['message'] = $message;
  header('location: /acme/products/');
  exit;
 } else {
  $message = "<p class='notice'>Error. $productName was not updated.</p>";
  include '../view/prod-update.php';
  exit;
}
 break;
 
 case 'del':
 $prodId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
 $prodInfo = getProductInfo($prodId);
 if (count($prodInfo) < 1) {
  $message = 'Sorry, no product information could be found.';
 }
 include '../view/prod-delete.php';
 exit;
 break;
 
case 'deleteProd':
 $prodName = filter_input(INPUT_POST, 'prodName', FILTER_SANITIZE_STRING);
 $prodId = filter_input(INPUT_POST, 'prodId', FILTER_SANITIZE_NUMBER_INT);

 $deleteResult = deleteProduct($prodId);
 if ($deleteResult) {
  $message = "<p class='notice'>Congratulations, $prodName was successfully deleted.</p>";
  $_SESSION['message'] = $message;
  header('location: /acme/products/');
  exit;
 } else {
  $message = "<p class='notice'>Error: $prodName was not deleted.</p>";
  $_SESSION['message'] = $message;
  header('location: /acme/products/');
  exit;
 }
 break;
 
 case 'category':
 $type = filter_input(INPUT_GET, 'type', FILTER_SANITIZE_STRING);
 $products = getProductsByCategory($type);

 if(!count($products)){
  $message = "<p class='notice'>Sorry, no $type products could be found.</p>";
 } else {
  $prodDisplay = buildProductsDisplay($products);
 }

 include '../view/category.php';
break;

    case 'product':
    $invId = filter_input(INPUT_GET, 'item', FILTER_SANITIZE_NUMBER_INT);
    $imageThumbnail = getThumbnail($invId);
    $item = filter_input(INPUT_GET, 'item', FILTER_SANITIZE_NUMBER_INT);
    $des = getallproductsinfo($item);
    $reviews = getReviews($invId);
    if(!count($des)){
    $message = "<p class='notice'>Sorry, no $item products could be found.</p>";
    } else {
    $productdetail = buildProductsDescription($des);
    $productThumbnail = buildProductsThumbnail($imageThumbnail);
    $productReviews = buildProductsReviews($reviews);
    }    
    include '../view/product-detail.php';  
    break;
}
?>