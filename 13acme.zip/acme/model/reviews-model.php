<?php

function storeReviews($revId, $reviewText, $clientId) {

 $db = acmeConnection();
 $sql = 'INSERT INTO reviews (InvId, reviewText, clientId) VALUES (:InvId, :reviewText, :clientId)';
 $stmt = $db->prepare($sql);
 // Store the review information
 $stmt->bindValue(':InvId', $revId, PDO::PARAM_INT);
  $stmt->bindValue(':clientId', $clientId, PDO::PARAM_INT);
 $stmt->bindValue(':reviewText', $reviewText, PDO::PARAM_STR);
 $stmt->execute();
 $rowsChanged = $stmt->rowCount();
 $stmt->closeCursor();
 return $rowsChanged;
}

// Get Image Information from images table
function getReviews($invId) {
 $db = acmeConnection();
 $sql ='SELECT reviewId, reviewText, reviewDate, invId, r.clientId, SUBSTRING(clientFirstname, 1, 1) AS clientFirstname, clientLastname FROM reviews r JOIN clients c ON c.clientId = r.clientId WHERE invId = :invId';
 //$sql = 'SELECT InvId, reviewText, clientId FROM reviews WHERE invId=:invId';
 $stmt = $db->prepare($sql);
 $stmt->bindValue(':invId', $invId, PDO::PARAM_INT);
 $stmt->execute();
 $review = $stmt->fetchAll(PDO::FETCH_NAMED);
 $stmt->closeCursor();
 return $review;
}

function getReviewsbyclient($clientId) {
 $db = acmeConnection();
 $sql = 'SELECT reviewId, InvId, reviewText, clientId FROM reviews WHERE clientId=:clientId';
 $stmt = $db->prepare($sql);
 $stmt->bindValue(':clientId', $clientId, PDO::PARAM_INT);
 $stmt->execute();
 $reviews = $stmt->fetchAll(PDO::FETCH_NAMED);
 $stmt->closeCursor();
 return $reviews;
}

function getReviewsbyitem($revId) {
 $db = acmeConnection();
 $sql = 'SELECT reviewId, InvId, reviewText, clientId FROM reviews WHERE reviewId=:reviewId ';
 $stmt = $db->prepare($sql);
  $stmt->bindValue(':reviewId', $revId, PDO::PARAM_INT);
 $stmt->execute();
 $review = $stmt->fetchAll(PDO::FETCH_NAMED);
 $stmt->closeCursor();
 return $review;
}

function updateReviews($reviewText,$revId) {
 $db = acmeConnection();
 $sql = 'UPDATE reviews SET reviewId=:reviewId, reviewText=:reviewText WHERE reviewId=:reviewId';
 //$sql = 'UPDATE reviews reviewId, reviewText, imgName, imgDate, inventory.invId, invName FROM images JOIN inventory ON images.invId = inventory.invId';
 $stmt = $db->prepare($sql);
 $stmt->bindValue(':reviewText', $reviewText, PDO::PARAM_STR);
 $stmt->bindValue(':reviewId', $revId, PDO::PARAM_INT);
 $stmt->execute();
 $rowsChanged = $stmt->rowCount();
 //$updateResult = $stmt->fetchAll(PDO::FETCH_NAMED);
 $stmt->closeCursor();
 return $rowsChanged;
 //return $updateResult;
}
// Delete image information from the images table
function deleteReviews($revId) {
 $db = acmeConnection();
 $sql = 'DELETE FROM reviews WHERE reviewId = :reviewId';
 $stmt = $db->prepare($sql);
 $stmt->bindValue(':reviewId', $revId, PDO::PARAM_INT);
 $stmt->execute();
 $result = $stmt->rowCount();
 $stmt->closeCursor();
 return $result;
}
