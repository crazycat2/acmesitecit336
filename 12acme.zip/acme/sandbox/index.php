<?php

/* 
sandbox controller
 */

// Create or access a Session
session_start();

$_SESSION ['toy'] = 'basketball';
$_SESSION ['duck'] = 'rubberduck';
$_SESSION ['officestuff'] = 'pen';
$_SESSION ['box'] = $tissuecontainer = ['tissue1', 'tissuee2'];

// for an action name value pair in post, if not there
//check for it in the get 
//assign to an $action variable

$action = filter_input(INPUT_POST, 'action');
if($action == NULL){
    $action = filter_input(INPUT_GET, 'action');
if($action == NULL){
    $action ='toy';
}

}

switch($action) {
case 'toy':
$value = $_SESSION['toy'];
include 'view.php';
break;
    
case 'duck':
$value = $_SESSION['duck'];
include 'view.php';
break;

case 'officestuff':
$value = $_SESSION['officestuff'];
include 'view.php';
break;  

case 'box':
$value = $_SESSION['box'];
include 'view.php';
break;
}