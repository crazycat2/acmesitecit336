<?php  
echo "today is:".date("Y-m-d");  
?> 