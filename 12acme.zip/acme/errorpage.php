<!DOCTYPE html>
<html>
<head>
<title>index</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="css/acme.css">
</head>

<body>
<header>
<img src="images/site/logo.gif">
</header>
<nav>
<?php include 'nav.php' ?> 
</nav>  
    
<main>
<h1>Error - sorry about that</h1>
</main>
<main2>

</main2>

<footer>
&copy Acme All rights reserved. All images are under fair use | Last Updated: 4/28/17
</footer>
</body>

</html>
