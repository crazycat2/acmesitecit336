<?php

/* 
products model
 */

/* new function will handle site regiatrstions */ 

  function addproducts($productName, $invDescription ,$invImage,$invThumbnail, $invPrice, $invStock,$invSize, $invWeight, $invLocation,$invVendor,$invStyle,$category){
// Create a connection object using the acme connection function
   $db = acmeConnection();
// The SQL statement
   $sql = 'INSERT INTO inventory (invName,invDescription,invImage,invThumbnail,invPrice,invStock,invSize,invWeight,invLocation,invVendor,invStyle, categoryId)
           VALUES (:invName, :invDescription, :invImage, :invThumbnail, :invPrice, :invStock,:invSize,:invWeight,:invLocation,:invVendor,:invStyle, :categoryId)';
// Create the prepared statement using the acme connection
   $stmt = $db->prepare($sql);
// The next four lines replace the placeholders in the SQL
// statement with the actual values in the variables
// and tells the database the type of data it is
   $stmt->bindValue(':invName', $productName, PDO::PARAM_STR);
   $stmt->bindValue(':invDescription', $invDescription, PDO::PARAM_STR);
   $stmt->bindValue(':invImage', $invImage, PDO::PARAM_STR);
   $stmt->bindValue(':invThumbnail', $invThumbnail, PDO::PARAM_STR);
   $stmt->bindValue(':invPrice', $invPrice, PDO::PARAM_STR);
   $stmt->bindValue(':invStock', $invStock, PDO::PARAM_STR);
   $stmt->bindValue(':invSize', $invSize, PDO::PARAM_STR);
   $stmt->bindValue(':invWeight', $invWeight, PDO::PARAM_STR);
   $stmt->bindValue(':invLocation', $invLocation, PDO::PARAM_STR);
   $stmt->bindValue(':invVendor', $invVendor, PDO::PARAM_STR);
   $stmt->bindValue(':invStyle', $invStyle, PDO::PARAM_STR);
   $stmt->bindValue(':categoryId', $category, PDO::PARAM_STR);
// Insert the data
   $stmt->execute();
// Ask how many rows changed as a result of our insert
   $rowsChanged = $stmt->rowCount();
// Close the database interaction
   $stmt->closeCursor();
// Return the indication of success (rows changed)
   return $rowsChanged;
}



  function addcategories($category){
// Create a connection object using the acme connection function
   $db = acmeConnection();
// The SQL statement
   $sql = 'INSERT INTO categories (categoryName)
           VALUES (:categoryName)';
// Create the prepared statement using the acme connection
   $stmt = $db->prepare($sql);
// The next four lines replace the placeholders in the SQL
// statement with the actual values in the variables
// and tells the database the type of data it is
   $stmt->bindValue(':categoryName', $category, PDO::PARAM_STR);
// Insert the data
   $stmt->execute();
// Ask how many rows changed as a result of our insert
   $rowsChanged = $stmt->rowCount();
// Close the database interaction
   $stmt->closeCursor();
// Return the indication of success (rows changed)
   return $rowsChanged;
}

function getProductBasics() {
 $db = acmeConnection();
 $sql = 'SELECT invName, invId FROM inventory ORDER BY invName ASC';
 $stmt = $db->prepare($sql);
 $stmt->execute();
 $products = $stmt->fetchAll(PDO::FETCH_NAMED);
 $stmt->closeCursor();
 return $products;
}

/* I'm selecting a single product based on its id */
function getProductInfo($prodId){
 $db = acmeConnection();
 $sql = 'SELECT * FROM inventory WHERE invId = :prodId';
 $stmt = $db->prepare($sql);
 $stmt->bindValue(':prodId', $prodId, PDO::PARAM_INT);
 $stmt->execute();
 $prodInfo = $stmt->fetch(PDO::FETCH_NAMED);
 $stmt->closeCursor();
 return $prodInfo;
}

/* update products */
function updateProduct($productName, $invDescription ,$invImage,$invThumbnail, $invPrice, $invStock,$invSize, $invWeight, $invLocation,$invVendor,$invStyle,$category, $prodId){
   
// Create a connection object using the acme connection function
   $db = acmeConnection();
// The SQL statement
   $sql = 'UPDATE inventory SET invName = :invName, invDescription = :invDescription, invImage = :invImage, invThumbnail = :invThumbnail, invPrice = :invPrice, invStock = :invStock, invSize = :invSize, invWeight = :invWeight, invLocation = :invLocation, invVendor = :invVendor, invStyle = :invStyle, categoryId = :categoryId WHERE invId = :prodId';
// Create the prepared statement using the acme connection
   $stmt = $db->prepare($sql);
// The next four lines replace the placeholders in the SQL
// statement with the actual values in the variables
// and tells the database the type of data it is
   $stmt->bindValue(':invName', $productName, PDO::PARAM_STR);
   $stmt->bindValue(':invDescription', $invDescription, PDO::PARAM_STR);
   $stmt->bindValue(':invImage', $invImage, PDO::PARAM_STR);
   $stmt->bindValue(':invThumbnail', $invThumbnail, PDO::PARAM_STR);
   $stmt->bindValue(':invPrice', $invPrice, PDO::PARAM_STR);
   $stmt->bindValue(':invStock', $invStock, PDO::PARAM_STR);
   $stmt->bindValue(':invSize', $invSize, PDO::PARAM_STR);
   $stmt->bindValue(':invWeight', $invWeight, PDO::PARAM_STR);
   $stmt->bindValue(':invLocation', $invLocation, PDO::PARAM_STR);
   $stmt->bindValue(':invVendor', $invVendor, PDO::PARAM_STR);
   $stmt->bindValue(':invStyle', $invStyle, PDO::PARAM_STR);
   $stmt->bindValue(':categoryId', $category, PDO::PARAM_STR);
   $stmt->bindValue(':prodId', $prodId, PDO::PARAM_INT);
// Insert the data
   $stmt->execute();
// Ask how many rows changed as a result of our insert
   $rowsChanged = $stmt->rowCount();
// Close the database interaction
   $stmt->closeCursor();
// Return the indication of success (rows changed)
   return $rowsChanged;
}

/*delete products */
function deleteProduct($prodId) {
 $db = acmeConnection();
 $sql = 'DELETE FROM inventory WHERE invId = :prodId';
 $stmt = $db->prepare($sql);
 $stmt->bindValue(':prodId', $prodId, PDO::PARAM_INT);
 $stmt->execute();
 $rowsChanged = $stmt->rowCount();
 $stmt->closeCursor();
 return $rowsChanged;
}

function getProductsByCategory($type){
 $db = acmeConnection();
 $sql = 'SELECT * FROM inventory WHERE categoryId IN (SELECT categoryId FROM categories WHERE categoryName = :catType)';
 $stmt = $db->prepare($sql);
 $stmt->bindValue(':catType', $type, PDO::PARAM_STR);
 $stmt->execute();
 $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
 $stmt->closeCursor();
 return $products;
}

function getallproductsinfo($item) {
 $db = acmeConnection();
 $sql = 'SELECT * FROM inventory WHERE invId = :itemId';
 $stmt = $db->prepare($sql);
 $stmt->bindValue('itemId', $item, PDO::PARAM_INT);
 $stmt->execute();
 $des = $stmt->fetch(PDO::FETCH_ASSOC);
 $stmt->closeCursor();
 return $des;
}