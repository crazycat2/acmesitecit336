<?php

/*
reviews controlller
 */
// Create or access a Session
session_start();

// Get the database connection file
require_once '../library/connections.php';
// Get the acme model for use as needed
require_once '../model/acme-model.php';
// Get the acme model for use as needed
require_once '../model/uploads-model.php';
// Get the accounts model
require_once '../model/accounts-model.php';
require_once '../model/products-model.php';
require_once '../library/functions.php';
// Get the acme model for use as needed
require_once '../model/reviews-model.php';

if(isset($_COOKIE['firstname'])){
  $cookieFirstname = filter_input(INPUT_COOKIE, 'firstname', FILTER_SANITIZE_STRING);
}

$action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING);
if ($action == NULL) {
$action = filter_input(INPUT_GET, 'action', FILTER_SANITIZE_STRING);
}

// directory name where uploaded reviews are stored
$revdir = '/acme/reviews';
// The path is the full path from the server root
$revpath = $_SERVER['DOCUMENT_ROOT'] . $revdir;

switch($action) {
case 'upload':
// Store the incoming product id
 $reviewText = filter_input(INPUT_POST, 'reviewText');
 $clientId = filter_input(INPUT_POST, 'clientId');
 $revId = filter_input(INPUT_POST, 'InvId');

  // Store the name of the uploaded image
  //$revName = $_FILES['file1']['name']; 
      // Insert the image information to the database, get the result
  $result = storeReviews($revId, $reviewText, $clientId);

  // Set a message based on the insert result
  if ($result) {
   $message = '<p class="notice">The upload succeeded.</p>';
  } else {
   $message = '<p class="notice">Sorry, the upload failed.</p>';
  }

 // Store message to session
 $_SESSION['message'] = $message;

 // Redirect to this controller for default action
 header('location: .');   
break;

case 'delete':
 $revId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
 $revInfo = getReviewsbyitem($revId);
 if (count($revInfo) < 1) {
  $message = 'Sorry, no reviews could be found.';
 }
 include '../view/rev-delete.php';
break;

case 'deletereview':
 $revName = filter_input(INPUT_POST, 'revName', FILTER_SANITIZE_STRING);
 $revId = filter_input(INPUT_POST, 'revId', FILTER_SANITIZE_NUMBER_INT);

 $deleteResult = deleteReviews($revId);
 if ($deleteResult) {
  $message = "<p class='notice'>Congratulations, $revName was successfully deleted.</p>";
  $_SESSION['message'] = $message;
  header('location: /acme/reviews/index.php');
  exit;
 } else {
  $message = "<p class='notice'>Error: $revName was not deleted.</p>";
  $_SESSION['message'] = $message;
  header('location: /acme/reviews/index.php');
  exit;
 }
 break;

case 'showreviews':
$reviews = getReviewsbyclient($_SESSION['clientData']['clientId']);
    
 if(count($reviews) > 0){
  $revList = '<table>';
  $revList .= '<thead>';
  $revList .= '<tr><th>Review Name</th><td>&nbsp;</td><td>&nbsp;</td></tr>';
  $revList .= '</thead>';
  $revList .= '<tbody>';
  foreach ($reviews as $review) {
   $revList .= "<tr><td>$review[reviewText]</td>";
   $revList .= "<td><a href='/acme/reviews?action=mod&id=$review[reviewId]' title='Click to modify'>Modify</a></td>";
   $revList .= "<td><a href='/acme/reviews?action=delete&id=$review[reviewId]' title='Click to delete'>Delete</a></td></tr>";
  }
   $revList .= '</tbody></table>';
  } else {
   $message = '<p class="notify">Sorry, no reviews were returned.</p>';
}
 include '../view/client-admin.php';
break;

case 'mod':
 $revId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
 $revInfo = getReviewsbyitem($revId);
 if (count($revInfo) < 1) {
  $message = 'Sorry, no reviews could be found.';
 }
 include '../view/rev-update.php';
break;

case 'update':
$reviewText= filter_input(INPUT_POST, 'reviewText', FILTER_SANITIZE_STRING);
$revId= filter_input(INPUT_POST, 'revId', FILTER_SANITIZE_NUMBER_INT);


 if (empty($reviewText)) {
  $message = '<p>Please complete all information for the new item! Double check the category of the item.</p>';
 include '../view/prod-update.php';
 exit;
}
$updateResult = updateReviews($reviewText,$revId);
//var_dump($updateResult);
//exit;

 if ($updateResult) {
  $message = "<p class='notice'>Congratulations, $reviewText was successfully updated.</p>";
  $_SESSION['message'] = $message;
  header('location: /acme/products/');
  exit;
 } else {
  $message = "<p class='notice'>Error. $reviewText was not updated.</p>";
  include '../view/rev-update.php';
  exit;
}
include ('...view/rev-update.php');
break;

default:
include ('../view/client-admin.php');
break;

}