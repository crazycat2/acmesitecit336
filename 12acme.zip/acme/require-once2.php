<?php  
include_once('require-once.php');  
 
?> 