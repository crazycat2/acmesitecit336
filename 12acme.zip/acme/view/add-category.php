<?php
if (
$loggedin = false){
header ('Location ../view/registration.php');
exit;
}

/* @var $clientLevel type */
if ($_SESSION['clientData']['clientLevel'] > 1) {
echo "products";
exit;
}

else {
    echo "you are not permitted to see this";
    exit;
}

;?>


<!DOCTYPE html>
<html>
<head>
<title>index</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="../css/acme.css">
</head>

<body>
<header>
<img src="images/site/logo.gif">
</header>
<nav>
<?php include 'nav.php' ?> 
<?php include 'cookie.php' ?>
</nav>  
    
<main>
<h1>add category</h1>
</main>
<main2>

<?php
if (isset($message)) {
 echo $message;
}
?>
<form method="post" action="/acme/products/index.php">
       
<form method="post" action="/acme/products/index.php"><?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <fielset>
        category name<br>
        <input type="text" name="categoryName"><br>
        <input type="submit" value="Submit">
        <input type="hidden" name="action" value="addcategory">
    </fielset>
</form>  
    
</main2>

<footer>
&copy Acme All rights reserved. All images are under fair use | Last Updated: 4/28/17
</footer>
</body>

</html>