<?php
if (isset($_SESSION['message'])) {
 $message = $_SESSION['message'];
}?>
<!DOCTYPE html>
<html>
<head>
<title>review management</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="../css/acme.css">
</head>

<body>
<header>
<img src="images/site/logo.gif" alt="logo">
</header>
<nav>
<?php include 'nav.php' ?> 
<?php include 'cookie.php'?>
</nav>  
    
<main>
<h1>Manage Reviews</h1>
</main>
<main2>
<h2>Add New Review</h2>
<?php
if (isset($message)) {
echo $message;
}
?>
<form action="/acme/reviews/" method="post" enctype="multipart/form-data">
<label>Upload Review:</label><br>
 <input type="textarea" name="reviewText"><br>
 <input type="submit" class="regbtn" value="Upload">
 <input type="hidden" name="action" value="upload">
</form>

<h2>Your Existing Reviews</h2>
<a href="../reviews/index.php?action=showreviews">click here to see</a>
<?php if (isset($revList)){ echo $revList;} ?>
</main2>

<footer>
&copy; Acme All rights reserved. All images are under fair use | Last Updated: 4/28/17
</footer>
</body>
</html>
<?php unset($_SESSION['message']); ?>