<?php
/* @var $clientLevel type */
if (!($_SESSION['clientData']['clientLevel'] > 1)) {
header ('Location ../view/registration.php');
exit;}
?>

<!DOCTYPE html>
<html>
<head>
<title>index
<?php if(isset($prodInfo['invName'])){ echo "Modify $prodInfo[invName] ";} elseif(isset($prodName)) { echo $prodName; }?> | Acme, Inc
</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="../css/acme.css">
</head>

<body>
<header>
<img src="images/site/logo.gif">
</header>
<nav>
<?php include 'nav.php' ?>
<?php include 'cookie.php' ?>
</nav>  
    
<main>
<h1><?php if(isset($prodInfo['invName'])){ echo "Modify $prodInfo[invName] ";} elseif(isset($prodName)) { echo $prodName; }?></h1>
<h1>modify reviews</h1>
</main>
<main2>
    
    
  
<?php
if (isset($message)) {
 echo $message;
}
?>
<form action="/acme/reviews/" method="post" enctype="multipart/form-data">
<textarea rows="10" cols="30" name="reviewText">
The cat was playing in the garden.
</textarea>
 <input type="submit" value="Submit Review">
 <input type="hidden" name="action" value="update">    
 <input type="hidden" name="revId" value="<?php echo $revId;?>">    
 <input type="hidden" name="clientId" value="<?php echo $_SESSION['clientData']['clientId'];?>">    
 
 </form>
</main2>

<footer>
&copy Acme All rights reserved. All images are under fair use | Last Updated: 4/28/17
</footer>
</body>

</html>