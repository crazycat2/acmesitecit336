<?php
/* if (
$loggedin = false){
header ('Location ../view/registration.php');
exit;
}
 * /
 */
require_once '../model/products-model.php';
/* @var $clientLevel type */
if (!($_SESSION['clientData']['clientLevel'] > 1)) {
header ('Location ../view/registration.php');
exit;
}
;?>
/* 
product management
 */
<?php
if ($_SESSION['clientData']['clientLevel'] < 2) {
 header('location: /acme/');
 if (isset($_SESSION['message'])) {
 $message = $_SESSION['message'];
}
 exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<title>index</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="../css/acme.css">
</head>

<body>
<header>
<img src="images/site/logo.gif" alt="logo">
</header>
<nav>
<?php include 'nav.php' ?> 
</nav>  
    
<main>
<h1>product management</h1>
</main>
<?php
if (isset($message)) {
 echo $message;
}
?>
<main2>
<a href="/acme/products/index.php?action=addproducts">add products</a>
<?php
if (isset($message)) {
 echo $message;
} if (isset($prodList)) {
 echo $prodList;
}
?>
<a href="/acme/products/index.php?action=addcategory">add a new category</a>
</main2>

<footer>
&copy; Acme All rights reserved. All images are under fair use | Last Updated: 4/28/17
</footer>
</body>

</html>
<?php unset($_SESSION['message']); ?>
