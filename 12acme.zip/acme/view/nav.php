  <ul>
        <li><a href="#" title="Go to the homepage">Home</a></li>
        <li><a href="#" title="awesome anvils">Anvils</a></li>
        <li><a href="#" title="cannons">Cannons</a></li>
        <li><a href="#" title="protection">Protection</a></li>
        <li><a href="#" title="rockets">Rockets</a></li>
        <li><a href="#" title="finest traps">Traps</a></li>
    </ul>

<php echo>