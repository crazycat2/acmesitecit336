<?php

/* 
 * Below the unordered list write a test to determine if the clientLevel of the logged in client is greater than 1.
 If the level is greater than 1 display a paragraph with a link inside that points to the products controller.
If the level is equal to 1, then the paragraph and link should not be built into the view by the server. This means that if the view is sent to the browser and you do a "view page source" the paragraph html is not present.
 */
/* $_SESSION['loggedin'] = FALSE */
// Get the accounts model

if (
$loggedin = false){
header ('Location ../view/registration.php');
exit;
}
;?>
  
<!DOCTYPE html>
<html>
<head>
<title>admin-view</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="../css/acme.css">
</head>
<body>
<header>
<img src="images/site/logo.gif" alt="logo">
</header>
<nav>
<?php echo $navList; ?> 
</nav>     
<main>
<h1>Admin View</h1>
</main>
<main2>
    <?php 
    /* @var $clientLevel type */
if ($_SESSION['clientData']['clientLevel'] > 1) {
echo $clientFirstname;
echo $email;
echo "administer products below";
echo '<p><a href="../products/index.php?action=showproducts">products</a>';
echo '<h1><a href="/acme/accounts/index.php?action=update-client">update account</a></h1>';
echo '<h1><a href="../view/client-admin.php">manage your reviews</a></h1>';
exit;
}

else {
    echo "you are not permitted to see this";
    echo "welcome" + $clientFirstname;
    echo $email;
    echo '<h1><a href="../view/client-update.php">update account</a></h1>';
    echo '<h1><a href="../view/client-admin.php">manage your reviews</a></h1>';
    exit;
}
;?>
    
      
        
   
</main2>
<footer>
&copy; Acme All rights reserved. All images are under fair use | Last Updated: 4/28/17
</footer>
</body>
</html>    